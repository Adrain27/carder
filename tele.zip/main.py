from telethon import TelegramClient 
from datetime import  datetime 
import pytz
import json

local = pytz.timezone('Asia/Kolkata')

with open("settings.json", "r") as file:
    settings = json.load(file)

api_id = settings['apiId']
api_hash = settings['apiHash']
client = TelegramClient('anon.session', api_id, api_hash)

async def main():
    print("Starting Go Scheduler made with ❤️ by @notxok")
    print("Client Authorized ✅")

    if settings['displayChatids']:
        await display_chat_ids(settings['displayLimit'])

    for task in settings['tasks']:
        mm=task['Schedule']['date']['month']
        dd=task['Schedule']['date']['day']
        hh=task['Schedule']['time']['hour']
        min=task['Schedule']['time']['minute']
        sec=task['Schedule']['time']['second']

        task_time = local.localize(datetime(year=task['Schedule']['date']['year'],
                             month=mm,
                             day=dd,
                             hour=hh,
                             minute=min,
                             second=sec)).astimezone(pytz.utc)


        await client.send_message(task['chatId'], task['message'], schedule=task_time)
        print(f"\nScheduled Task [{task['taskName']}] Successfully 🚀")

        if task['Schedule']['recursive']['isRecursive']:
            count = task['Schedule']['recursive']['count']
            gap = task['Schedule']['recursive']['gap']
            for _ in range(1, count + 1):
                min += gap
                if min > 59:
                    hh += 1
                    min %= 60
                if hh > 23:
                    dd += 1
                    hh %= 24

                task_time = local.localize(datetime(year=task['Schedule']['date']['year'],
                                     month=mm,
                                     day=dd,
                                     hour=hh,
                                     minute=min,
                                     second=sec)).astimezone(pytz.utc)

                await client.send_message(task['chatId'], task['message'], schedule=task_time)
                print(f"Scheduled Task [{task['taskName']}] Successfully 🚀")

async def display_chat_ids(limit):
    async for dialog in client.iter_dialogs(limit=limit):
        print(f"Name: {dialog.name} | ChatId: {dialog.id}")

with client:
    client.loop.run_until_complete(main())
